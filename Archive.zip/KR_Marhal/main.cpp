#include <iostream>
#include <cmath>
#include "assignment_9-10.h"
#include "structures.h"
#include "assignment_1-5.h"
#include "test.h"

void function(double (*f)(double), const double arg)
{

}

int main()
{
    void first();

    void second();

    void third();

    void fifths();

    void fourth();

    void sixth();

    void seventh();

    void eights();

    void nineth();

    void tenth();
    return 0;
}