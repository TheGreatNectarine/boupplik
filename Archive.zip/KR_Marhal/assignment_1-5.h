//
// Created by Nick Marhal on 12/5/17.
//

#ifndef KR_MARHAL_ASSIGNMENT_1_5_H
#define KR_MARHAL_ASSIGNMENT_1_5_H

bool task_1(double x, double y);

double task_2(double x, double n);

void task_3(double &a, double &b);

void exch(const double &a, const double &b);

char *task_4(long long unsigned int);

unsigned task_5(unsigned n);

#endif //KR_MARHAL_ASSIGNMENT_1_5_H
