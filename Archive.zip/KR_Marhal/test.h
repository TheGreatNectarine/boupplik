//
// Created by Nick Marhal on 12/6/17.
//

#ifndef KR_MARHAL_TEST_H
#define KR_MARHAL_TEST_H

void test_1();

void test_2();

void test_3();

void test_4();

void test_5();

void test_6();

void test_7();

void test_8();

void test_9();

void test_10();


#endif //KR_MARHAL_TEST_H
