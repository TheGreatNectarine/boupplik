//
// Created by Nick Marhal on 12/8/17.
//

#ifndef KR_MARHAL_FUNCTIONS_H
#define KR_MARHAL_FUNCTIONS_H

#endif //KR_MARHAL_FUNCTIONS_H
