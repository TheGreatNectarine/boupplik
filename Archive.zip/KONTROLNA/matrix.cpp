//
// Created by Nick Marhal on 12/3/17.
//
#include <iostream>
#include <cstddef>
#include "functions.h"



