#include <iostream>
#include "functions.h"

int main()
{
	first();
	second();
	third();
	fifths();
	fourth();
	sixth();
	seventh();
	eights();
	nineth();
	tenth();
	return 0;
}

