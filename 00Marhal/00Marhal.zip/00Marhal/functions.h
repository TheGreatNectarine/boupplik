//
// Created by Nick Marhal on 10/31/17.
//

#ifndef INC_00MARHAL_FUNCTIONS_H
#define INC_00MARHAL_FUNCTIONS_H

void check_sum();

void check_modulo();

void check_gcd();

void check_sine();

void check_Chebyshev();



#endif //INC_00MARHAL_FUNCTIONS_H
