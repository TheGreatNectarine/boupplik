//
// Created by Nick Marhal on 11/1/17.
//

#ifndef INC_00MARHAL_HELPERS_H
#define INC_00MARHAL_HELPERS_H

double absolute(double x);

double float_mod(double x0, double x1);

#endif //INC_00MARHAL_HELPERS_H
