//
// Created by Nick Marhal on 11/5/17.
//

#ifndef MARHAL07_TEST_H
#define MARHAL07_TEST_H

void test_fib();

#endif //MARHAL07_TEST_H
