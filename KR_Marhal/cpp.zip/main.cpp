#include <iostream>
#include <cmath>
#include "assignment_9-10.h"
#include "structures.h"
#include "assignment_1-5.h"
#include "test.h"

void function(double (*f)(double), const double arg)
{

}

int main()
{
    test_1();
    test_2();
    test_3();
    test_4();
    test_5();
    test_6();
    test_7();
    test_8();
    test_9();
    test_10();
    return 0;
}