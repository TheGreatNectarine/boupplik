#include "sorting.h"

int main()
{
    run_tests();
    return 0;
}
