//
// Created by Nick Marhal on 10/30/17.
//

#include "functions.h"

double arctan(double x)
{
    double res(0);
    double prev(0);
    double pow(x);
    int    denominator(1);
    int    unity(1);
    do {
        prev = res;
        res += unity * (pow / denominator);
        pow *= x * x;
        denominator += 2;
        unity *= -1;
    } while (absolute(res - prev) != 0);
    return res;
}
