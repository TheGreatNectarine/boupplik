//
// Created by Nick Marhal on 10/30/17.
//
#include <cmath>
#include "functions.h"

double float_mod(double x0, double x1)
{
    while (x0 > x1) {
        x0 -= x1;
    }
    return x0;
}

double cosine(double x)
{
    x = float_mod(absolute(x), 2 * M_PI);
    double            res(1), next(1);
    for (unsigned int i(0); absolute(next) != 0;) {
        next = -1 * next * x * x / (++i * ++i);
        res += next;
    }
    return res;
}
