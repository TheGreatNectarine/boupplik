//
// Created by Nick Marhal on 10/30/17.
//

#ifndef INC_01MARHAL_FUNCTIONS_H
#define INC_01MARHAL_FUNCTIONS_H

double exponent(double x);
double cosine(double x);
double arctan(double x);
double absolute(double x);
double float_mod(double x0, double x1);

#endif //INC_01MARHAL_FUNCTIONS_H
