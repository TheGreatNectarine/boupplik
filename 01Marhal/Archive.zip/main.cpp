#include <iostream>
#include "functions.h"
#include <cmath>

void test_exp();

void test_cos();

void test_atan();

int main()
{
    std::cout.precision(10);
    std::cout << "==============TESTING EXPONENT==============" << std::endl << std::endl << std::endl;
    test_exp();
    std::cout << "==============TESTING COSINE==============" << std::endl << std::endl << std::endl;
    test_cos();
    std::cout << "==============TESTING ATAN==============" << std::endl << std::endl << std::endl;
    test_atan();
    return 0;
}

//After testing it was determined that a function is valid for x € [-707, 707]
//For x >= |±708| function loops infinitely
void test_exp()
{
    std::cout << "EXPONENT" << std::endl;
    for (double x = -707; x <= 707; x+=10.03) {
        std::cout << "x:" << x << " written exp: " << exponent(x) << "; built-in exp: " << exp(x) << std::endl
                  << std::endl;
    }
    std::cout << "END TEST" << std::endl;
}

//For x € [~ -400000,~400000] precise up to 7 decimal digits.
// Supposingly infinitely precise, precision limited only by machine's architecture
void test_cos()
{
    std::cout << "COSINE" << std::endl;
    for (double x = -500000; x <= 500000; x += 10000.03) {
        std::cout << "x:" << x << " written cos: " << cosine(x) << "; built-in cos: " << cos(x) << std::endl
                  << std::endl;
    }
    std::cout << "END TEST" << std::endl;
}

//For x € (-1,1), precise at least for 10 decimal digits.
//Calculating function for other values is impossible as
//Taylor series for this function is valid only for x € (-1,1)
void test_atan()
{
    std::cout << "ATAN" << std::endl;
    for (double x = -0.999; x <= 1; x += 0.1) {
        std::cout << "x:" << x << " written atan: " << arctan(x) << "; built-in atan: " << atan(x) << std::endl
                  << std::endl;
    }
    std::cout << "END TEST" << std::endl;
}