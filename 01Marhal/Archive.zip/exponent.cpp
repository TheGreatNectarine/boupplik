//
// Created by Nick Marhal on 10/30/17.
//
#include <iostream>
#include <cmath>
#include "functions.h"


double exponent(double x)
{
    if (x < 0) {
        return 1 / exponent(-x);
    }
    double            res(1), next(1);
    for (unsigned int i(1); absolute(next) != 0; ++i) {
        next *= x / i;
        res += next;
    }
    return res;
}

double absolute(double x)
{
    return x > 0 ? x : -x;
}


